package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Login extends AppCompatActivity {
    ///declare variable
    private EditText emailEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    emailEditText = findViewById(R.id.editTextTextEmailAddress);
    passwordEditText = findViewById(R.id.editTextTextPassword);
    loginButton = findViewById(R.id.loginbutton);
    registerButton = findViewById(R.id.registerButton);

        //here is for login button
        loginButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String email = emailEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            // Here we are Validate input fields
            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password) ) {
                Toast.makeText(Login.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }


             //here we are checking authorization using password and email
            if (isValidCredentials(email, password)) {
                Toast.makeText(Login.this, "Successfully logged in", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(Login.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        }
    });

        //here is for register button
        registerButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(Login.this, Register.class);
            startActivity(intent);
        }
    });
}

    private boolean isValidCredentials(String email, String password) {
        String validEmail = "abc@abc.com";
        String validPassword = "password";
        return email.equals(validEmail) && password.equals(validPassword);
    }
}
