package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    ///declare variable

    private EditText FirstName;
    private EditText FamilyName;
    private EditText dateOfBirth;
    private EditText email;
    private EditText password;
    private Button register;
    private Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        FirstName = findViewById(R.id.editTextTextPersonName);
        FamilyName = findViewById(R.id.editTextTextPersonName2);
        dateOfBirth = findViewById(R.id.editTextTextPersonName3);
        email = findViewById(R.id.editTextTextPersonName5);
        password = findViewById(R.id.editTextTextPersonName6);
        register = findViewById(R.id.button);
        login = findViewById(R.id.signButton2);

 register.setOnClickListener(new View.OnClickListener() {
@Override
   public void onClick(View v) {
        String firstName = FirstName.getText().toString().trim();
        String lastName = FamilyName.getText().toString().trim();
        String dateOfBirthh = dateOfBirth.getText().toString().trim();
        String emaill = email.getText().toString().trim();
        String passwordd = password.getText().toString().trim();

        // Here we are Validating input fields
        if (TextUtils.isEmpty(firstName) || TextUtils.isEmpty(lastName) ||
        TextUtils.isEmpty(dateOfBirthh) || TextUtils.isEmpty(emaill) ||
        TextUtils.isEmpty(passwordd)) {
        Toast.makeText(Register.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        return;
        }

        //here we are applying conditions
        if (firstName.length() < 3 || firstName.length() > 30) {
        Toast.makeText(Register.this, "First name should be between 3 and 30 characters", Toast.LENGTH_SHORT).show();
        return;
        }

        Toast.makeText(Register.this, "Registration successful", Toast.LENGTH_SHORT).show();
        finish();
         }
        });


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Register.this, Login.class);
                startActivity(intent);
            }
        });

            }
}
